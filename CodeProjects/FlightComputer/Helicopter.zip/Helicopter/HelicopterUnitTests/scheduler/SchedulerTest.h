/*
 * SchedulerTest.h
 *
 * Created: 3/3/2013 6:24:32 PM
 *  Author: HP User
 */ 


#ifndef SCHEDULERTEST_H_
#define SCHEDULERTEST_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;

int schedulertask_test(TestCase *test);


#endif /* SCHEDULERTEST_H_ */