/*
 * SPIDriver.h
 *
 * Created: 1/27/2014 9:41:34 PM
 *  Author: HP User
 */ 


#ifndef SPIDRIVERTESTS_H_
#define SPIDRIVERTESTS_H_


#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;

int spi_messaging_test(TestCase *test);


#endif /* SPIDRIVERTESTS_H_ */