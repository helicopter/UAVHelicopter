/*
 * ControlLawOuterLoopTask.h
 *
 * Created: 9/21/2013 4:02:58 PM
 *  Author: HP User
 */ 


#ifndef PIDControllerTests_H_
#define PIDControllerTests_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;


int calculateYaw_test(TestCase *test);



#endif /* PIDControllerTests_H_ */