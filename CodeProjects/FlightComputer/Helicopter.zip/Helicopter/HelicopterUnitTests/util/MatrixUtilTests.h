/*
 * MatrixUtilTest.h
 *
 * Created: 2/1/2014 2:25:28 PM
 *  Author: HP User
 */ 


#ifndef MATRIXUTILTESTS_H_
#define MATRIXUTILTESTS_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;


int matrixrotation_test(TestCase *test);



#endif /* MATRIXUTILTESTS_H_ */