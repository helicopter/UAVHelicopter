/*
 * MathTests.h
 *
 * Created: 12/15/2013 4:46:10 PM
 *  Author: HP User
 */ 


#ifndef COORDINATEUTILTESTS_H_
#define COORDINATEUTILTESTS_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;


int coordinateutil_test(TestCase *test);



#endif /* COORDINATEUTILTESTS_H_ */