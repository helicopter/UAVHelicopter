/*
 * Timer.h
 *
 * Created: 9/14/2013 6:26:58 PM
 *  Author: HP User
 */ 


#ifndef TIMERTESTS_H_
#define TIMERTESTS_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;


int timeout_test(TestCase *test);



#endif /* TIMERTESTS_H_ */