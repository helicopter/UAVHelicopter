/*
 * MagnetometerDriver.cpp
 *
 * Created: 8/22/2013 10:00:03 PM
 *  Author: HP User
 */ 

#include "MagnetometerDriver.h"

using namespace helicopter::drivers;

//TODO Implement this
int MagnetometerDriver::initialize()
{
	//TODO Implement This
	return 0;
}

int MagnetometerDriver::readSensor(int16_t *rawMagX, int16_t *rawMagY, int16_t *rawMagZ)
{
	//TODO Implement This
	return 0;
}