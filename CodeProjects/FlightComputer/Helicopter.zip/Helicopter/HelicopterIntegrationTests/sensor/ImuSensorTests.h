/*
 * AccelerometerTests.h
 *
 * Created: 2/1/2014 12:24:29 PM
 *  Author: HP User
 */ 


#ifndef IMUSENSORTESTS_H_
#define IMUSENSORTESTS_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;

//int readimu_test(TestCase *test);
int readmag_test(TestCase *test);
int magdriver_test(TestCase *test);

#endif /* IMUSENSORTESTS_H_ */