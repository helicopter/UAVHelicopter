/*
 * BarometerSensorTests.h
 *
 * Created: 2/18/2014 9:39:29 PM
 *  Author: HP User
 */ 


#ifndef BAROMETERSENSORTESTS_H_
#define BAROMETERSENSORTESTS_H_

#include "TestCase.h"

using namespace helicoptertestscommon::util::testframework;


int readbaro_test(TestCase *test);



#endif /* BAROMETERSENSORTESTS_H_ */